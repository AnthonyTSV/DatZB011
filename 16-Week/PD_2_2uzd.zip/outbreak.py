from SEIR import SEIR, solve_SEIR, plot_SEIR
from ODESolver import RungeKutta4

def beta(t):
    raise NotImplementedError(
        "Implement beta function with time-dependent transmission rate."
    )  # REMOVE THIS LINE WHEN IMPLEMENTING

if __name__ == "__main__":
    raise NotImplementedError(
        "Implement main block to run the SEIR model with time-dependent beta."
    )  # REMOVE THIS LINE WHEN IMPLEMENTING
