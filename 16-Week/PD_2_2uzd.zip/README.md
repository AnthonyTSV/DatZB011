# Pandēmijas modelēšana ar Diferenciālvienādojumiem un Python

Šeit būs mani komentāri